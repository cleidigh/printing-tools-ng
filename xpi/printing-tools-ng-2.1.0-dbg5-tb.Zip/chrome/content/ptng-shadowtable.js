console.debug('shadow table dialogue');


function addShadowTable() {
	console.debug('shadow table');
	console.debug(window.arguments[0]);
}

window.addEventListener("load", function (event) {
	addShadowTable();
});
