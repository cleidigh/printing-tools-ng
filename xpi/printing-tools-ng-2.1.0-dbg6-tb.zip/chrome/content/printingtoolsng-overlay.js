
function openPTdialog(abook) {
		openDialog("chrome://printingtoolsng/content/ptng-options.xhtml", "", "chrome,centerscreen", false, abook);
}
